# 🌐 IMDb Top 250 Movies Analysis - Project Report  

## 📊 1. Introduction  
The IMDb Top 250 Movies dataset provides valuable insights into popular films, their ratings, and audience reception. This project focuses on web scraping, data processing, and cleaning to create a structured dataset for further analysis.

---

## 🛠 2. Tools & Technologies Used  
- **Python** (Jupyter Notebook)  
- **Libraries:** Requests, BeautifulSoup, Pandas, NumPy  
- **Data Storage:** JSON, CSV  

---

## 🔄 3. Workflow Overview  
1. **Data Collection** - Scraping movie details from IMDb.  
2. **Data Preprocessing** - Structuring the raw data into a tabular format.  
3. **Data Cleaning** - Handling missing values, duplicate removal, and text normalization.  
4. **Dataset Creation** - Exporting a final clean dataset.  

---

## 📖 4. Data Collection (Web Scraping)  
- **Website:** IMDb Top 250 Movies page.  
- **Methodology:** Used `requests` to fetch HTML content and `BeautifulSoup` to parse movie details.  
- **Saved Output:** Raw data stored in `raw_imdb_data.json`.

---

## 🗓 5. Data Preprocessing  
- Converted JSON data into structured Pandas DataFrame.  
- Saved an initial data sample (`initial_sample.csv`).  

---

## 🏢 6. Data Cleaning  
- **Missing Values:** Filled missing text fields with `N/A` and rating fields with mean values.  
- **Duplicate Removal:** Checked for and eliminated duplicate entries.  
- **Text Normalization:** Standardized case formatting and removed unnecessary whitespace.  
- **Final Dataset:** Cleaned data saved as `cleaned_full_dataset.csv`.

---

## 📊 7. Results & Insights  
- Successfully extracted and cleaned IMDb Top 250 Movies data.  
- Ready-to-use dataset available for further analysis.  
- Identified trends in movie ratings and descriptions.

---

## 📝 8. Challenges & Solutions  
| Challenge | Solution |
|-----------|----------|
| Dynamic IMDb structure | Used BeautifulSoup to handle changing HTML tags |
| Missing ratings | Imputed missing values with mean ratings |
| Large dataset size | Optimized storage using CSV format |


---

## 📚 9. Conclusion  
This project successfully scrapes and processes IMDb Top 250 Movies data, making it ready for further statistical analysis and visualization. The structured dataset provides valuable insights into audience preferences and movie ratings.

---

## 📌 Author  
**Nithish Nuthalapati**  
Master’s in Business Analytics | Data Analyst Enthusiast  

---

## 📚 License  
This project is for educational purposes only. IMDb data is publicly available but belongs to IMDb.

